<?php


namespace Nextend;


use Nextend\Framework\Pattern\GetPathTrait;
use Nextend\Framework\Pattern\SingletonTrait;
use Nextend\SmartSlider3\Platform\Joomla\JoomlaShim;

class Nextend {

    use GetPathTrait;
    use SingletonTrait;

    protected function init() {
    }
}